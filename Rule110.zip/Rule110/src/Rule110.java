import java.util.Scanner;
import java.util.Arrays;

public class Rule110 {
    public static void main(String[] args) throws Exception {
        Scanner input = new Scanner(System.in);
        
        System.out.print("Numero righe: ");
        int rows = Integer.parseInt(input.nextLine());
        System.out.print("Numero colonne: ");
        int cols = Integer.parseInt(input.nextLine());

        String firstLine = CreateTable(rows, cols);
        Rule110(firstLine, cols);

    }

    public static String CreateTable(int rows, int cols) {
        String res = "";
        
        for (int i = 0; i < cols - 1; i++) { //all zeros
            res += 0;
        }
        res += 1;                           //last 1

        return res;
    }

    public static void Rule110(String firstLine, int cols) {
        int i = 0;
        String nextLine = "";
        while (i < cols - 1) {
            for (int j = 0; j < firstLine.length() - 1; j++) {
                String upperLine = firstLine.substring(j, (j+2) % firstLine.length());
                nextLine += Calc(upperLine);
            }
        }
    }

    public static String Calc(String upper) {
        switch (upper) {
            case "111":
                return "0";
                break;
            case "110":
                return "1";
                break;
            case "101":
                return "1";
                break;
            case "100":
                return "0";
                break;
            case "011":
                return "1";
                break;
            case "010":
                return "1";
                break;
            case "001":
                return "1";
                break;
            case "000":
                return "0";
                break;
        }
    }
}
